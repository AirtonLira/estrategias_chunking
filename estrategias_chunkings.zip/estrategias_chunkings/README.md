# Estratégias de Chunking

## Recomendações Práticas

1. **Para documentos técnicos**: Use Recursive ou Semantic chunking
2. **Para textos simples**: Fixed-size pode ser suficiente
3. **Para manter contexto**: Sliding window com overlap de 20-30%
4. **Para otimizar performance**: Combine estratégias (híbrido)